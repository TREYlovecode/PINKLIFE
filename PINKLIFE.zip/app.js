App({
  onLaunch() {
    
  },
  onShow: function () {
  },
  onHide: function () {
  }
})
