// start.js

Page({
    data: {

    },
    //跳转到天气页面
    navigate: function() {
        wx.navigateTo({
            url: '../wifi_station/tianqi/tianqi',
        })
    },
    loadCity: function (latitude, longitude){
      var page=this;
      wx.request({
        url: 'https://api.map.baidu.com/geocoder/v2/?ak=0wc3g1eZGK5K80EQlqT9Hv21sDw7p20C&location='+latitude+','+longitude+'&output=json',//百度地图api
        data: {
          x: '',
          y: ''//未使用data
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        success: function (res) {
          console.log(res.data);
          var city=res.data.result.addressComponent.city;
          city=city.replace("市","");
          console.log(city);
          page.setData({city:city});
          page.loadWeather(city);
          page.loadLife(city)
        }
      })
    },
    
})