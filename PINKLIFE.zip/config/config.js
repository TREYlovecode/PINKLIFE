const config = {
  name: '轻松天气',
  version: '1.3.7',
  versionDate: '2020.11.05',
  versionInfo: '\n- 问题修复',
  request: {
    host: 'https://ali-weather.showapi.com',
    header: { 'Authorization': 'APPCODE ' + '41ed284c7c244b57b3f9e7214cb5a50d' },
  },
}

export default config;
