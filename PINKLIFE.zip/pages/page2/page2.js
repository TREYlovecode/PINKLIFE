// pages/DEMO3/DEMO3.js
Page({
  data:{
    num:0
},
//输入框事件的执行逻辑
handleInput(e){
this.setData({
  num:e.detail.value
})
},
//加减按钮的事件
handletap(e){
const operation = e.currentTarget.dataset.operation;
this.setData({
 num:this.data.num + operation
})
 },
 handletap2(e){
  this.setData({
    num:0
  })
   }
 })
